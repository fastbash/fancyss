{
  "gfwlist": {
    "name": "gfwlist.conf",
    "date": "2025-01-02 02:11",
    "md5": "7ec447bbec4b7d691727c2eab0ef2259",
    "count": "7127"
  },
  "chnroute_maxmind": {
    "name": "chnroute_maxmind.txt",
    "date": "2024-11-19 16:05",
    "md5": "41302df69ece45fe11d3e9ddcad2c47e",
    "count": "7212",
    "count_ip": "345532148",
    "source": "maxmind",
    "url": "https://github.com/firehol/blocklist-ipsets/blob/master/geolite2_country/country_cn.netset"
  },
  "chnroute_ipip": {
    "name": "chnroute_ipip.txt",
    "date": "2024-11-19 16:05",
    "md5": "4dc3943cb26f84c28cbdcbd46ff3399d",
    "count": "7395",
    "count_ip": "354951706",
    "source": "ipip",
    "url": "https://github.com/firehol/blocklist-ipsets/blob/master/ipip_country/ipip_country_cn.netset"
  },
  "chnroute_17mon": {
    "name": "chnroute_17mon.txt",
    "date": "2024-11-19 16:05",
    "md5": "4e37080ae9dddb3349e5491cf6d137b0",
    "count": "6885",
    "count_ip": "354433392",
    "source": "17mon",
    "url": "https://github.com/17mon/china_ip_list"
  },
  "chnroute_misakaio": {
    "name": "chnroute_misakaio.txt",
    "date": "2025-01-08 02:11",
    "md5": "0c6c0fd2f3026bac8e3c1c16f546fb0d",
    "count": "4189",
    "count_ip": "286205952",
    "source": "misakaio",
    "url": "https://github.com/misakaio/chnroutes2/blob/master/chnroutes.txt"
  },
  "chnroute_cnisp": {
    "name": "chnroute_cnisp.txt",
    "date": "2024-11-19 16:04",
    "md5": "4e37080ae9dddb3349e5491cf6d137b0",
    "count": "6885",
    "count_ip": "354433392",
    "source": "cnisp",
    "url": "https://github.com/gaoyifan/china-operator-ip"
  },
  "chnroute_apnic": {
    "name": "chnroute_apnic.txt",
    "date": "2025-01-08 02:11",
    "md5": "415cbf8e8930f0bacb9146a5d9072485",
    "count": "8668",
    "count_ip": "343142400",
    "source": "apnic",
    "url": "http://ftp.apnic.net/apnic/stats/apnic/delegated-apnic-latest"
  },
  "chnroute": {
    "name": "chnroute.txt",
    "date": "2025-01-08 02:11",
    "md5": "86fc4d573120d8f4fe9e184efaa6416d",
    "count": "8395",
    "count_ip": "376319236",
    "source": "fancyss",
    "url": "https://github.com/fastbash/fancyss/tree/3.0/rules"
  },
  "cdn_china": {
    "name": "cdn.txt",
    "date": "2025-01-06 02:11",
    "md5": "195ce4ed4af9dd24df0ef5c8e96a62e5",
    "count": "93642"
  },
  "apple_china": {
    "name": "apple_china.txt",
    "date": "2024-11-19 16:05",
    "md5": "216ccd6e184055ba6133687a1c42aa3b",
    "count": "174"
  },
  "google_china": {
    "name": "google_china.txt",
    "date": "2024-11-19 16:05",
    "md5": "6899bb37a930b7b4c89528035c90f5f4",
    "count": "191"
  },
  "cdn_test": {
    "name": "cdn_test.txt",
    "date": "2024-11-19 16:05",
    "md5": "84b034525bca6b60fbffb68dc8fbb9cd",
    "count": "87"
  }
}
